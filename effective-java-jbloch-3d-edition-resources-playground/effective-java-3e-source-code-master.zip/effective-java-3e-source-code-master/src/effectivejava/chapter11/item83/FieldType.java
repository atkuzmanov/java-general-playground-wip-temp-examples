package effectivejava.chapter11.item83;

public class FieldType {
}
