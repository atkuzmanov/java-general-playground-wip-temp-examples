package effectivejava.chapter2.item7;

// (Thrown by Stack program on Page 26)
public class EmptyStackException extends IllegalStateException {
}
