package effectivejava.chapter3.item10;

public enum Color { RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET }
