package effectivejava.chapter4.item25;

//  (Page 115)
public class Main {
    public static void main(String[] args) {
        System.out.println(Utensil.NAME + Dessert.NAME);
    }
}