	This program is essentially a large, sequential test case. In contrast to
	previous versions, which contained numerous projects, one for each pattern,
	all examples are executed sequentially. More so, I didn't want to introduce
	a 3rd-party unit test library. After all, the intent is to illustrate C++
	principles and best practices and patterns from the book, not support a full
	SDLC (Software Development Life Cycle).

	Discussion and comments regarding this release are available at:
	http://hfdpcpp.wordpress.com/white-gold/
	