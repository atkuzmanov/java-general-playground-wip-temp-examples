package com.example.javamvnspringbtblank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavamvnspringbtblankApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavamvnspringbtblankApplication.class, args);
	}

}
