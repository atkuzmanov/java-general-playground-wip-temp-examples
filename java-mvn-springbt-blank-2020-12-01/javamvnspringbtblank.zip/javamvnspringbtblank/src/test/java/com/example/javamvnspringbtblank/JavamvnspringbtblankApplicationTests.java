package com.example.javamvnspringbtblank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavamvnspringbtblankApplicationTests {

	@Test
	void contextLoads() {
	}

}
